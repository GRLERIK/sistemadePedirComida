public class Entregador {
    int id;
    String nome;
    int veiculo;

}
