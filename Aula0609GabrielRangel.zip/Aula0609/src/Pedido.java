public class Pedido {
    int numero;
    String itens;
    String endereco;
    String status;
    Entregador entregador;

}
