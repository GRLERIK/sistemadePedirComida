// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Entregador entregador1 = new Entregador();
        entregador1.id = 82709;
        entregador1.nome = "André";
        entregador1.veiculo = 2;

        Pedido pedido1 = new Pedido();
        pedido1.endereco = "Unifor";
        pedido1.itens = "pizza";
        pedido1.numero = 60908;
        pedido1.status = "Preparando";
        pedido1.entregador = entregador1;







    }
}